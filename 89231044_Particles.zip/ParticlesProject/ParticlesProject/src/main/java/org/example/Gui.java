package org.example;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

import static org.example.Particle.distance;
import static org.example.Particle.generate;

    public class Gui extends JPanel{
    private ArrayList<Particle> particles;
    private int cycles;
    private int currentCycle = 0;
    private boolean isShown;
    private Timer timer;

    public Gui(int n, int cycles, boolean isShown) {
        this.particles = generate(n);
        this.cycles = cycles;
        this.isShown = isShown;

        JFrame frame = new JFrame("Particles");

        if(isShown) {
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setSize(800, 600);
            frame.add(this);
            frame.setResizable(true);
            frame.setVisible(true);
        }

        startSimulation(frame);
    }

    private void startSimulation(JFrame frame) {
        long start = System.currentTimeMillis();

        if(!isShown) {
            for(int i = 0; i < cycles; i++) {
                updateParticles();
                currentCycle++;
            }
            long end = System.currentTimeMillis();
            System.out.println("The Simulation has been successful!\n " +
                    "Run time in ms: " + (end-start)+ "\n" +
                    "Cycles passed: " + currentCycle);

            System.exit(0);
            return;
        }

        else {
            timer = new Timer(1000 / 60, e -> { // 60 FPS
                if (currentCycle >= cycles) {
                    timer.stop();
                    long end = System.currentTimeMillis();
                    JOptionPane.showMessageDialog(frame, "The Simulation has been successful!\n " +
                            "Run time in ms: " + (end-start)+ "\n" +
                            "Cycles passed: " + currentCycle, "Success", JOptionPane.INFORMATION_MESSAGE);


                    System.exit(0);
                    return;
                }

                updateParticles();
                repaint();
                currentCycle++;
            });
        }

        if(isShown) timer.start();
    }

    private void updateParticles() {

        for (Particle particle : particles) {
            particle.updatePosition(getWidth(), getHeight());
        }


        checkCollision(particles);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawParticles(g);
    }

    private void drawParticles(Graphics g) {
        Graphics2D gfx = (Graphics2D) g;
        for (Particle particle : particles) {
            if (particle.getCharge() >= 1) {
                gfx.setColor(Color.BLUE);
            } else {
                gfx.setColor(Color.RED);
            }
            int x = particle.getX();
            int y = particle.getY();
            gfx.fillOval(x, y, particle.dimension, particle.dimension);
        }
    }

    private void checkCollision(ArrayList<Particle> particles) {
        for (int i = 0; i < particles.size(); i++) {
            Particle p1 = particles.get(i);
            for (int j = i + 1; j < particles.size(); j++) {
                Particle p2 = particles.get(j);

                double dist = distance(p1, p2);
                if (dist <= p1.radius) {
                    double force = Math.abs(p1.getCharge() * p2.getCharge()) / Math.pow((dist+1),2);


                    double dx = (p2.getX() - p1.getX());
                    double dy = (p2.getY() - p1.getY());

                    if (p1.getCharge() * p2.getCharge() > 0) { // Same charge: repulsion
                       /*
                        dx*=-1*force;
                        dy*=-1*force;
                        p1.velocityX = dx + p1.velocityX;
                        p1.velocityY = dy + p1.velocityY;
                        p2.velocityX = dx - p2.velocityX;
                        p2.velocityY = dy - p2.velocityY;
*/
                        p1.velocityX -= dx * force*0.2;
                        p1.velocityY -= dy * force*0.2;
                        p2.velocityX += dx * force*0.2;
                        p2.velocityY += dy * force*0.2;
                        if(!isShown) System.out.println("Particle with id["+p1.id+"]"+" is " +
                                "in collision with particle with id["+p2.id+"] and they " +
                                "different charge.\n"+
                                p1.id+" coordinates: ("+p1.x+","+p1.y+")\n"+
                                p2.id+" coordinates: ("+p1.x+","+p1.y+")");

                        p1.inCollision.add(p2);
                        p2.inCollision.add(p1);

                    } else {
                        /*dx*=force;
                        dy*=force;
                        p1.velocityX = dx + p1.velocityX;
                        p1.velocityY = dy + p1.velocityY;
                        p2.velocityX = dx - p2.velocityX;
                        p2.velocityY = dy - p2.velocityY;
*/

                        // Opposite charge: attraction
                        p1.velocityX += dx * force*0.2;
                        p1.velocityY += dy * force*0.2;
                        p2.velocityX -= dx * force*0.2;
                        p2.velocityY -= dy * force*0.2;

                        p1.inCollision.add(p2);
                        p2.inCollision.add(p1);
                    }
                }
            }
        }
    }

}