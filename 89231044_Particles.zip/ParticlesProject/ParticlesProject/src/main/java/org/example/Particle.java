package org.example;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class Particle {
    public int dimension;
    public int x;
    public int y;
    private int charge;
    public int id;
    public ArrayList<Particle> inCollision = new ArrayList<>();
    public int radius = 50;
    public double velocityX;
    public double velocityY;

    public Particle(int id,int x, int y, Color color, int charge,int dimension) {
        this.id=id;
        this.x = x;
        this.y = y;
        this.charge = charge;
        Random r = new Random();
        double velocity = r.nextDouble(1,3);
        this.velocityX = velocity;
        this.velocityY = velocity;
        this.dimension = dimension;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getCharge() {
        return charge;
    }

    public void updatePosition(int panelWidth, int panelHeight) {
        double minVelocity = 2;
        double edgeRepulsion = 1;
        double dampingFactor = 0.99;

        if(x < 20) velocityX += edgeRepulsion;
        if(y < 20) velocityY += edgeRepulsion;

        if(x + dimension > panelWidth - 20) velocityX -= edgeRepulsion;
        if(y + dimension > panelWidth - 20) velocityY -= edgeRepulsion;

        if(x < 5) {
            velocityX = Math.abs(velocityX);
            if(Math.abs(velocityX) < minVelocity) velocityX = minVelocity;
        }

        if(y < 5) {
            velocityY = Math.abs(velocityY);
            if(Math.abs(velocityY) < minVelocity) velocityY = minVelocity;
        }

        if(x + dimension > panelWidth - 5) {
            velocityX = Math.abs(velocityX);

            if(Math.abs(velocityX) < minVelocity) velocityX = -minVelocity;
            else velocityX = -velocityX;
        }

        if(y + dimension > panelHeight - 5) {
            velocityY = Math.abs(velocityY);

            if(Math.abs(velocityY) < minVelocity) velocityY = -minVelocity;
            else velocityY = -velocityY;
        }

        for(int i = 0; i < inCollision.size(); i++) {
            Particle collisionParticle = inCollision.get(i);

            int xMin = x;
            int xMax = x + dimension;

            int collisionParticleXMin = collisionParticle.x;
            int collisionParticleXMax = collisionParticle.x + dimension;

            if (collisionParticleXMin <= xMin && collisionParticleXMax >= xMax) {
                velocityX = -velocityX;
                velocityY = -velocityY;

                x += velocityX;
                y += velocityY;
            }
        }

        x += (int) (velocityX < 0 ? Math.floor(velocityX) : Math.ceil(velocityX));
        y += (int) (velocityY < 0 ? Math.floor(velocityY) : Math.ceil(velocityY));

        if(Math.abs(velocityX) > 3) velocityX *= dampingFactor;
        if(Math.abs(velocityY) > 3) velocityY *= dampingFactor;

        inCollision = new ArrayList<>();

        limitVelocity(5.0);
    }

    private void limitVelocity(double maxVelocity) {
        double speed = Math.sqrt(velocityX * velocityX + velocityY * velocityY);

        if(speed > maxVelocity) {
            velocityX = (velocityX / speed) * maxVelocity;
            velocityY = (velocityY / speed) * maxVelocity;
        }
    }

    public static ArrayList<Particle> generate(int count) {
        ArrayList<Particle> particles = new ArrayList<>();
        Random r = new Random();
        for (int i = 0; i < count; i++) {
            int x = r.nextInt(750);
            int y = r.nextInt(550);
            int charge = r.nextInt(-5,6) + 1;
            particles.add(new Particle(i,x, y, charge >= 0 ? Color.BLUE : Color.RED, charge, generateDimension(count)));
        }
        return particles;
    }

    public static double distance(Particle a, Particle b) {
        int ax = a.getX();
        int ay = a.getY();
        int bx = b.getX();
        int by = b.getY();
        return Math.sqrt(Math.pow(ax - bx, 2) + Math.pow(ay - by, 2));
    }

    private static int generateDimension(int count) {
        if(count <= 100) return 10;
        else if(count <= 500) return 8;
        else if(count <= 1000) return 7;
        return 5;
    }
}