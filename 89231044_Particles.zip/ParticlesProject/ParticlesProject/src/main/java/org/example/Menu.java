package org.example;

import javax.swing.*;
import java.awt.*;

public class Menu {

    public Menu() {
        JFrame frame = new JFrame();
        frame.setTitle("Particle Simulator");
        JOptionPane.showMessageDialog(frame,
                "Hello! Welcome to the Particle Simulator!\n" +
                        "It simulates the collision between positive and negative charged particles.\n" +
                        "The simulation runs for a given number of cycles and at the end shows\n" +
                        "Runtime in ms, and cycles passed.",
                "Information", JOptionPane.INFORMATION_MESSAGE);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setSize(300, 300);
        frame.setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        frame.add(panel);


        JButton sequential = new JButton("Sequential");
        JButton parallel = new JButton("Parallel");
        JButton distributed = new JButton("Distributed");

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;

        panel.add(sequential, gbc);

        gbc.gridy = 1;
        panel.add(parallel, gbc);

        gbc.gridy = 2;
        panel.add(distributed, gbc);

        sequential.addActionListener(e -> {
            try {
                Optimal optimal = new Optimal();
                //Main main = new Main();
                frame.dispose();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new Menu();
    }
}
